**Fine-tuning**: Adapting (continued training) a pre-trained AI [[base model]] with new, task-specific data to perform better in a particular area. E.g. the [[training]] of a large language model on medical texts so it gives accurate answers to health questions.

Tags: [[High Performance Computing (HPC)]] 
