**Base model** AI: An AI model trained on general data, used as a starting point before any task-specific adaptation or [[fine-tuning|Fine-tuning]].

